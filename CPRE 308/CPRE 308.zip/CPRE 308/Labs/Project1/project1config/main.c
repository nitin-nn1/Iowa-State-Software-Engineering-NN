#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char **argv) {
    // Set the prompt
    char* prompt;
    char *args[2];

    // User input infinite loop
    if(argc < 3){
        prompt = "308sh>";
    }
    else{
        prompt = argv[2];
        prompt = strcat(prompt, ">");
    }
    char* input;
    while (1) {

        printf(prompt);
        // Get user input

        fgets(input, 256, stdin);

        strtok(input, "\n");

        // ---------- Builtin Commands ---------------------------------------
        if (strcmp(input, "exit") == 0) {
            return 0;
        }

        else if (strcmp(input, "pid") == 0) {
            printf("Shell Process ID: %d\n", getpid());
        }

        else if (strcmp(input, "ppid") == 0){
            printf("Shell Parent process ID: %d\n", getppid());
        }

        else if(strncmp(input, "cd", 2 ) == 0){ //might need to fix the directory changes
            if(strlen(input) > 3){
                char* absolutePath = strtok(input, " ");
                absolutePath = strtok(NULL, "\0");

                if(chdir(absolutePath) == 0){
                    printf("New Path: %s\n", getcwd(NULL, 0));
                }else{
                    printf("Path doesnt exist\n");
                }
            }
            else{
                chdir(getenv("HOME"));
                printf("Parent Directory %s\n", getcwd(NULL, 0));
            }
        }
        else if(strcmp(input, "pwd") == 0){
            printf("Working Directory: %s\n", getcwd(NULL, 0));
        }
        else {
            // ---------- NONBuiltin Commands ---------------------------------------
            printf("Child PID is %d. \n", getpid());
            if(strcmp(input, "ls") == 0){
                args[0] = "/bin/ls";
                if(fork() == 0) {
                    execv(args[0], args);
                }
                printf("\n");
                usleep(100000);
            }
            else if(strcmp(input, "ps") == 0){

            }
            else{

            }
        }
    }
    return 0;
}