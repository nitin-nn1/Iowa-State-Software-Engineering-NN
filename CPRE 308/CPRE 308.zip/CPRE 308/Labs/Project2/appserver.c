//
// Created by Nitin's PC on 4/18/2021.
//
#include <stdio.h>
#include<string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <pthread.h>
#include "Bank.c"

void request(char* input);
int currentID = 1;

void main(int argc, char** argv){
    if(argc != 4){
        puts("Please run with arguments: <worker threads> <num of accounts> <file>");
        return;
    }

    long threa = strtol(argv[1], NULL, 0);
    long acc = strtol(argv[2], NULL, 0);
    char* file = argv[3];

    printf("%d thread, %ld accounts, to %s\n", threa, acc, file);
    initialize_accounts(acc);

    //ask for the user input
    char* user = NULL;
    size_t len = 0;

    while(1){
        puts("Please enter the command u need: ");
        getline(&user, &len, stdin);
        strtok(user, "\n");
        request(user);
    }
    free_accounts(); //free up the rest of the accounts
}

void request(char* input){
    char* command = strtok(input, " ");

    if((strcmp(command, "TRANS") == 0)){
        return;
    }
    else if(strcmp(command, "CHECK") == 0){
        return;
    }
    else if(strcmp(command, "END") == 0){
        puts("End of the program!");
        return;
    }

}











