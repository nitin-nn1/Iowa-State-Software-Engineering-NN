#include <signal.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

void my_routine();

int main() {
    signal(SIGFPE, my_routine);

    printf("Dividing by zero?! NANI?!: \n");

    int a = 4;
    a = a/0;

    printf("Can't Be Reached!\n");
    return 0;
}



void my_routine() {
    printf("Caught a SIGFPE\n");
    exit(0);
}