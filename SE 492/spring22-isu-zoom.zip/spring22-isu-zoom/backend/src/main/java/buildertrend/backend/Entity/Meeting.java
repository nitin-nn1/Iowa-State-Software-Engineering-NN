package buildertrend.backend.Entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

/**
 *User Class that holds related attributes with set and get functions. Directly creates a table with spring to then be saved in the repository.
 *
 * @author abanwell
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
public class Meeting {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int meetingID;
    /*
    public String ;
    public String ;
    public String ;
    public String ;
    public String ;*/

    @ElementCollection
    public List<Integer> participants;
    public Integer tempPtpsID;


                    //get functions//
    /**
     *Get function for meetingID
     *
     * @return int meetingID
     */
    public Integer getId() { return meetingID; }

    /**
     *Get function for participants
     *
     * @return participants List-Integer-
     */
    public List<Integer> getParticipants() { return participants; }//get whole list
    /**
     *Get function for genrePreference by id
     *
     * @param index
     * @return Integer participants
     */
    public Integer getUserAtIndex(int index) {
        return participants.get(index);
    } //get user id at index






    //set functions//
    /**
     *Set function for id
     *
     * @param meetingID
     */
    public void setId(int meetingID) { this.meetingID = meetingID; }

    /**
     *Set function for whole participants list
     *
     * @param list
     */
    public void addParticipants(List<Integer> list) {
        for(int i =0; i<list.size(); i++){
            participants.add(list.get(i));
        }
    }

    /**
     *Set function for sublist participants
     *
     * @param list
     */
    public void setParticipants(List<Integer> list) {
        participants = list;
    }

    /**
     *Set function for UserID
     *
     * @param userID
     */
    public void addUser(Integer userID) {
        participants.add(userID);
    }


}
