package buildertrend.backend.Controller;

import buildertrend.backend.Entity.User;
import buildertrend.backend.Repository.UserDB;
import buildertrend.backend.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 *User Controller Class that autowires the repository for access to repository. Links incoming Json requests to mapping through the entity to access the requested variables.
 *
 * @author abanwell
 */
@RestController
public class UserController {

    @Autowired
    private UserService service;
    @Autowired
    UserDB db;


    /**
     *Get function for User by id
     * @param id
     * @return User
     */
    @GetMapping("/user/{id}")
    User getUser(@PathVariable Integer id) { return db.findByID(id); }


    /**
     *Get function for User by username and password with authentication
     * @param username
     * @param password
     * @return User
     */
    @PostMapping("/user/auth/{username}")
    User getUserbyName(@PathVariable String username, @RequestBody String password) {
        User temp = db.findByUserName(username);
        if(temp.password.equals(password)){
            temp.password = "true";
            return temp;
        }
        else{
            temp.password = "false";
        }
        return temp;
    }




    /**
     *Get function for UserDB
     *
     * @return List-User- UserDB
     */
    @RequestMapping("/userDB")
    List<User> hello() {
        return db.findAll();
    }


    /**
     *Set function for User
     * @param user
     * @return User
     */
    @PostMapping("/addUser")
    public User addUser(@RequestBody User user) {
        db.save(user);
        return user;
    }


    /**
     *Set function for User by id
     *
     * @param id
     * @return User
     */
    @PutMapping("/user/{id}")
    public User updateUser(@PathVariable Integer id, @RequestBody User u) {
        User old_u = db.findByID(id);
        old_u.setId(id);
        if(u.email==null){
            old_u.setEmail(old_u.email);
        }
        else{
            old_u.setEmail(u.email);
        }
        if(u.fname==null){
            old_u.setFname(old_u.fname);
        }
        else{
            old_u.setFname(u.fname);
        }
        if(u.lname==null){
            old_u.setLname(old_u.lname);
        }
        else{
            old_u.setLname(u.lname);
        }
        if(u.username==null){
            old_u.setUsername(old_u.username);
        }
        else{
            old_u.setUsername(u.username);
        }
        if(u.password==null){
            old_u.setPassword(old_u.password);
        }
        else{
            old_u.setPassword(u.password);
        }

        db.save(old_u);
        return old_u;
    }






    /**
     *delete function for User by id
     *
     * @param id
     * @return String text
     */
    @DeleteMapping("/user/{id}")
    String deletePerson(@PathVariable Integer id) {
        User tempUser = db.findByID(id);
        db.delete(tempUser);
        return "deleted " + tempUser.username;
    }



}
