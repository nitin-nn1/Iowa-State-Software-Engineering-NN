-- Author: Keven Lin
DROP TABLE IF EXISTS USER;
create table if not exists USER (
    id int not NULL AUTO_INCREMENT,
    email varchar(255),
    fname varchar(255),
    lname varchar(255),
    password varchar(255),
    username varchar(255)
    );