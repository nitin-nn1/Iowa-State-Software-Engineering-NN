#BuilderTrend Zoom API's Backend 👏😎👏

---

A SpringBoot Application 

## Getting Started 

---

Connecting to H2 database:

```
http://localhost:8080/h2
```

```aidl
username: sa
password:
```
```aidl
datasource link: jdbc:h2:mem:h2db
```