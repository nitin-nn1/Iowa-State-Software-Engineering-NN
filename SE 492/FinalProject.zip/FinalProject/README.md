# BuilderTrend Zoom Fullstack Webapp

Build the frontend React app and run with Spring backend:

Both are hosted on http://localhost:8080
```
mvn clean install
mvn spring-boot:run
```
---
For development and debugging run the applications separately.

### Buildertrend Zoom API's SpringBoot Backend 👏😎👏

```
mvn spring-boot:run
```
Connecting to H2 database:
http://localhost:8080/h2

```
username: sa
password:
```
```
datasource link: jdbc:h2:mem:h2db
```

### Buildertrend Zoom React Frontend

Go to /src/main/frontend
```
yarn install
yarn start
```

http://localhost:3000
