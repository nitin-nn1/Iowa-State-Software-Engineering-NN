package buildertrend.backend.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.xml.stream.events.Comment;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;

/**
 *User Class that holds related attributes with set and get functions. Directly creates a table with spring to then be saved in the repository.
 *
 * @author abanwell
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
@JsonIgnoreProperties
public class Meeting {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int id;
    public int duration;//Only used for scheduled meetings (MINUTES)
    //public int participantsID;

    public String agenda;
    public String password = "default"; //max length of 10 and only alphanumeric and @, -, _, *
    public String audio = "both"; //(both, telephony, or voip) default is both

    public Boolean default_password = false;

    //@ElementCollection
    //@JsonIgnore
    //@OneToMany(mappedBy="meeting")
    //public List<User> participants = new ArrayList<>();
    //@ElementCollection
    //@Transient
    //public List<Integer> participants = new ArrayList<>();

    //@ManyToMany(fetch = FetchType.LAZY)

    //participants.add(1);
    //public Integer tempPtpsID;
    //@OneToMany(fetch = FetchType.EAGER, mappedBy = "Meeting", cascade = CascadeType.ALL)
    //private Collection<Comment> participants = new LinkedHashSet<Comment>();


                    //get functions//
    /**
     *Get function for meetingID
     *
     * @return int meetingID
     */
    public Integer getId() { return id; }

    /**
     *Get function for duration
     *
     * @return int duration
     */
    public Integer getDuration() { return duration; }

    /**
     *Get function for agenda
     *
     * @return string agenda
     */
    public String getAgenda() { return agenda; }

    /**
     *Get function for password
     *
     * @return string password
     */
    public String getPassword() { return password; }

    /**
     *Get function for default_password
     *
     * @return boolean default_password
     */
    public Boolean getDefaultPass() { return default_password; }

    /**
     *Get function for audio
     *
     * @return string audio
     */
    public String getAudio() { return audio; }

    /**
     *Get function for participants
     *
     * @return participants List-Integer-
     */
    //Collection<User>
    //public List<Integer> getParticipants() { return participants; }//get whole list
    /**
     *Get function for genrePreference by id
     *
     * @param index
     * @return Integer participants
     */
    /*public Integer getUserAtIndex(int index) {
        return participants.get(index);
    } //get user id at index*/






    //set functions//
    /**
     *Set function for id
     *
     * @param id
     */
    public void setId(int id) { this.id = id; }

    /**
     *Set function for duration
     *
     * @param duration
     */
    public void setDuration(int duration) { this.duration = duration; }

    /**
     *Set function for agenda
     *
     * @param agenda
     */
    public void setAgenda(String agenda) { this.agenda = agenda; }

    /**
     *Set function for password
     *
     * @param password
     */
    public void setPassword(String password) { this.password = password; }

    /**
     *Set function for audio
     *
     * @param audio
     */
    public void setAudio(String audio) { this.audio = audio; }

    /**
     *Set function for default_password
     *
     * @param default_password
     */
    public void setDefaultPass(Boolean default_password) { this.default_password = default_password; }

    /**
     *Set function for whole participants list
     *
     * @param list
     */
    /*public void addParticipants(List<Integer> list) {
        for (int i = 0; i < list.size(); i++) {
            participants.add(list.get(i));
        }
    }*/

    /**
     *Set function for sublist participants
     *
     * @param list
     */
    /*public void setParticipants(List<Integer> list) {
        participants = list;
    }*/

    /**
     *Set function for UserID
     *
     * @param user
     */
    /*public void addUser(User user) {
        getParticipants().add(user);
        //participants.add(userID);
    }*/
    //public void addUser(Integer user) {
        //getParticipants().add(user);
        //participants.add(userID);
    //}

}
