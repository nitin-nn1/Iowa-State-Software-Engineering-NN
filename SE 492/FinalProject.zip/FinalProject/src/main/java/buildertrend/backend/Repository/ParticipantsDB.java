package buildertrend.backend.Repository;

import buildertrend.backend.Entity.Meeting;
import buildertrend.backend.Entity.Participants;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Adam Banwell
 * Repository that stores Users
 *
 *
 */
@Repository
public interface ParticipantsDB extends JpaRepository<Participants, Integer> {
    @Query(value = "SELECT * FROM Participants ORDER BY id", nativeQuery = true)
    List<Participants> findAll();

    @Query("SELECT u FROM Participants u WHERE u.id = ?1")
    Participants findByID(int id);

    @Query("SELECT i FROM Participants i WHERE i.meetingID = ?1")
    List<Participants> findAllByMeetingID(int id);

    @Query("SELECT i.userID FROM Participants i WHERE i.meetingID = ?1")
    List<Integer> findAllUsersByID(int id);

}
