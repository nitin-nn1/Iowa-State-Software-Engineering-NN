package buildertrend.backend.Entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

/**
 *User Class that holds related attributes with set and get functions. Directly creates a table with spring to then be saved in the repository.
 *
 * @author abanwell
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
public class Participants {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int id;
    public int meetingID;
    public int userID;

    //@ManyToOne
    //private Meeting meeting;

    //get functions//
    /**
     *Get function for id
     *
     * @return int id
     */
    public Integer getId() { return id; }

    /**
     *Get function for meetingID
     *
     * @return int meetingID
     */
    public Integer getMeetingID() { return meetingID; }

    /**
     *Get function for duration
     *
     * @return int duration
     */
    public Integer getUser() { return userID; }



    //set functions//
    /**
     *Set function for id
     *
     * @param id
     */
    public void setId(int id) { this.id = id; }

    /**
     *Set function for userID
     *
     * @param userID
     */
    public void setUserID(int userID) { this.userID = userID; }

    /**
     *Set function for userID
     *
     * @param meetingID
     */
    public void setMeetingID(int meetingID) { this.meetingID = meetingID; }



}
