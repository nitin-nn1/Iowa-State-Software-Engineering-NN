package buildertrend.backend.Controller;

import buildertrend.backend.Entity.Meeting;
import buildertrend.backend.Entity.Participants;
import buildertrend.backend.Entity.User;
import buildertrend.backend.Repository.MeetingDB;
import buildertrend.backend.Repository.ParticipantsDB;
import buildertrend.backend.Repository.UserDB;
import buildertrend.backend.Service.UserService;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.persistence.criteria.CriteriaBuilder;
import java.util.List;

/**
 *User Controller Class that autowires the repository for access to repository. Links incoming Json requests to mapping through the entity to access the requested variables.
 *
 * @author abanwell
 */
@RestController
public class MeetingController {

    @Autowired
    private UserService service;
    @Autowired
    MeetingDB Meetingdb;
    @Autowired
    ParticipantsDB ParticipantsDB;
    @Autowired
    UserDB db;


    /**
     *Get function for Meeting by id
     * @param id
     * @return Meeting
     */
    @GetMapping("/meeting/{id}")
    Meeting getMeeting(@PathVariable Integer id) { return Meetingdb.findByID(id); }

    /**
     *Get function for MeetingDB
     *
     * @return List-Meeting- MeetingDB
     */
    @RequestMapping("/meetingDB")
    List<Meeting> getMeetings() {
        return Meetingdb.findAll();
    }

    /**
     *Get function for Participants by meeting id
     * @param id
     * @return Participants
     */
    @GetMapping("/participants/{id}")
    List<Integer> getParticipants(@PathVariable Integer id) { return ParticipantsDB.findAllUsersByID(id); }

    /**
     *Get function for ParticipantsDB
     *
     * @return List-Participants- ParticipantsDB
     */
    @RequestMapping("/participantsDB")
    List<Participants> getParticipantsDB() {
        return ParticipantsDB.findAll();
    }

    /**
     *Get function for meeting by id and password with authentication
     * @param userID
     * @param current
     * @return Meeting
     */
    @PostMapping("/meeting/auth/{userID}")
    Boolean joinMeeting(@PathVariable Integer userID, @RequestBody Meeting current) {

        Meeting temp = Meetingdb.findByID(current.id);
        System.out.print(temp);
        if(temp == null) {
            return false;
        }

        if(temp.password.equals(current.password)){
            List<Integer> users = ParticipantsDB.findAllUsersByID(current.id);
            if(!users.contains(userID)){
                Participants p = new Participants();
                p.setUserID(userID);
                p.setMeetingID(current.id);
                ParticipantsDB.save(p);
            }
            return true;
        }
        else{
            return false;
        }
    }

    /**
     *Get function for meeting by id and password with authentication
     * @param userID
     * @param current
     * @return Meeting
     */
    @PostMapping("/meeting/leave/{userID}")
    Boolean leaveMeeting(@PathVariable Integer userID, @RequestBody Meeting current) {

        List<Participants> p = ParticipantsDB.findAllByMeetingID(current.id);

        for (Participants user : p) {
            if (user.getUserID() == userID) {
                ParticipantsDB.delete(user);
                return true;
            }
        }
        return false;
    }


    /**
     *Set function for User
     * @param meeting
     * @return Meeting
     */
    @PostMapping("/addMeeting")
    public Meeting addMeeting(@RequestBody Meeting meeting) {
        if(meeting.password.equals("default")){
            meeting.setDefault_password(true);
        }
        Meetingdb.save(meeting);
        return meeting;
    }


    /**
     *delete function for meeting by id
     *
     * @param id
     * @return String text
     */
    @DeleteMapping("/meeting/{id}")
    String deleteMeeting(@PathVariable Integer id) {
        Meeting tempMeeting = Meetingdb.findByID(id);
        Meetingdb.delete(tempMeeting);

        List<Participants> users = ParticipantsDB.findAllByMeetingID(id);
        for (Participants user : users) {
            ParticipantsDB.delete(user);
        }

        return "deleted " + tempMeeting.id;
    }



}
