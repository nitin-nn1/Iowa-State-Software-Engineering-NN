package buildertrend.backend.Service;

import buildertrend.backend.Entity.User;
import buildertrend.backend.Repository.UserDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("UserService")//UserService
public class UserService {

    @Autowired
    private UserDB repository;

    public User findByID(int id) {
        return repository.findByID(id);
    }

    public User findByUserName(String name) {
        return repository.findByUserName(name);
    }

    public User findByFname(String fname) {
        return repository.findByFname(fname);
    }

    public User findByLname(String lname) {
        return repository.findByLname(lname);
    }

    public User findByPassword(String password){ return repository.findByPassword(password); }

    public User findByEmail(String email) {
        return repository.findByEmail(email);
    }

}
