package buildertrend.backend.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

/**
 *User Class that holds related attributes with set and get functions. Directly creates a table with spring to then be saved in the repository.
 *
 * @author abanwell
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
@JsonIgnoreProperties
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int id;
    public String email;
    public String fname;
    public String lname;
    public String username;
    public String password;

    //@JsonIgnore
    //@ManyToOne
    //private Meeting meeting;
                    //get functions//
    /**
     *Get function for id
     *
     * @return int id
     */
    public Integer getId() { return id; }
    /**
     *Get function for email
     *
     * @return String email
     */
    public String getEmail() { return email; }
    /**
     *Get function for fname
     *
     * @return String fname
     */
    public String getFname() { return fname; }
    /**
     *Get function for lname
     *
     * @return String lname
     */
    public String getLname() { return lname; }
    /**
     *Get function for username
     *
     * @return String username
     */
    public String getUsername() { return username; }
    /**
     *Get function for password
     *
     * @return String password
     */
    public String getPassword() { return password; }




                        //set functions//
    /**
     *Set function for id
     *
     * @param id
     */
    public void setId(int id) { this.id = id; }
    /**
     *Set function for email
     *
     * @param email
     */
    public void setEmail(String email) { this.email = email; }
    /**
     *Set function for fname
     *
     * @param fname
     */
    public void setFname(String fname) { this.fname = fname; }
    /**
     *Set function for lname
     *
     * @param lname
     */
    public void setLname(String lname) { this.lname = lname; }
    /**
     *Set function for username
     *
     * @param username
     */
    public void setUsername(String username) { this.username = username; }
    /**
     *Set function for password
     *
     * @param password
     */
    public void setPassword(String password) { this.password = password; }
}
