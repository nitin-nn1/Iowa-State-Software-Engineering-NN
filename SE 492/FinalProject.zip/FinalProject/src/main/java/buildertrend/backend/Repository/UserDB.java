package buildertrend.backend.Repository;

import buildertrend.backend.Entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Adam Banwell
 * Repository that stores Users
 *
 *
 */
@Repository
public interface UserDB extends JpaRepository<User, Integer> {
    @Query(value = "SELECT * FROM user ORDER BY id", nativeQuery = true)
    List<User> findAll();

    @Query("SELECT u FROM User u WHERE u.id = ?1")
    User findByID(int id);

    @Query("SELECT u FROM User u WHERE u.username = ?1")
    User findByUserName(String name);

    @Query("SELECT u FROM User u WHERE u.fname = ?1")
    User findByFname(String fname);

    @Query("SELECT u FROM User u WHERE u.email = ?1")
    User findByEmail(String email);

    @Query("SELECT u FROM User u WHERE u.lname = ?1")
    User findByLname(String lname);

    @Query("SELECT u FROM User u WHERE u.password = ?1")
    User findByPassword(String password);
}
