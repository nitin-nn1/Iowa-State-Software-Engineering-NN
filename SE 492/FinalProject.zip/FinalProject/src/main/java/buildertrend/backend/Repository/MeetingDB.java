package buildertrend.backend.Repository;

import buildertrend.backend.Entity.Meeting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Adam Banwell
 * Repository that stores Users
 *
 *
 */
@Repository
public interface MeetingDB extends JpaRepository<Meeting, Integer> {
    @Query(value = "SELECT * FROM Meeting ORDER BY id", nativeQuery = true)
    List<Meeting> findAll();

    @Query("SELECT m FROM Meeting m WHERE m.id = ?1")
    Meeting findByID(int id);

}
