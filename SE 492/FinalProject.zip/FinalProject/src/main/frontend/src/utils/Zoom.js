import React from 'react';
import {ZoomMtg} from "@zoomus/websdk";

const signatureEndpoint = 'https://zoomwebsdkconnectforschoolisu2.herokuapp.com/'
const zoomMeetingEndpoint = 'https://api.zoom.us/v2/users/';
const sdkKey = 'Zl6yhgX55oUm3mAyFIa7cbWlxHXYcIiALxTP';

var leaveUrl = 'http://localhost:3000'
const screenName = 'React'
const userEmail = 'zoomtestman789123@gmail.com'
var registrantToken = ''

// pass in the registrant's token if your meeting or webinar requires registration. More info here:
// Meetings: https://marketplace.zoom.us/docs/sdk/native-sdks/web/client-view/meetings#join-registered
// Webinars: https://marketplace.zoom.us/docs/sdk/native-sdks/web/client-view/webinars#join-registered

const zoomMeetingSDK = document.getElementById('zmmtg-root');
zoomMeetingSDK.style.display = 'none';

export function getSignature(meetingInfo) {
    const role = meetingInfo.role ? 1 : 0;

    fetch(signatureEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            meetingNumber: meetingInfo.meetingNumber,
            role: role
        })
    }).then(res => res.json())
        .then(response => {
            startMeeting(response.signature, meetingInfo)
        }).catch(error => {
        console.error(error)
    })
}

export function startMeeting(signature, meetingInfo) {
    zoomMeetingSDK.style.display = 'block';

    ZoomMtg.init({
        leaveUrl: leaveUrl,
        success: (success) => {
            console.log(success)

            ZoomMtg.join({
                signature: signature,
                sdkKey: sdkKey,
                userName: screenName,
                meetingNumber: meetingInfo.meetingNumber,
                passWord: meetingInfo.meetingPassword,
                zak: meetingInfo.zakToken,
                success: (success) => {
                    console.log(success);
                },
                error: (error) => {
                    console.log(error);
                }
            })

        },
        error: (error) => {
            console.log(error)
        }
    })
}