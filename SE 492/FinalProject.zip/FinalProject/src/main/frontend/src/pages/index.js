import React from "react";
import {Routes, Route} from "react-router-dom";

import {Home} from "./Home";
import {Zoom} from "./Zoom";
import {Calendar} from "./Calendar";
import Layout from "../components/Layout";

const Webpages = () => {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Home/>}/>
        <Route path="/calendar" element={<Calendar/>}/>
        <Route path="/zoom" element={<Zoom />}/>
      </Routes>
    </Layout>
  );
};

export default Webpages;