import MeetingForm from "../components/MeetingForm";
import ScheduleForm from "../components/ScheduleForm";

export function Zoom() {

    return (
        <>
            <main>
                <h1>Use this to join or start a zoom meeting!</h1>
                <p>You can do this, I believe in you.</p>
                <MeetingForm/>
                <ScheduleForm/>
            </main>
        </>
    );
}

