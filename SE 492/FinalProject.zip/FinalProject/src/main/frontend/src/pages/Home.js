import {getSignature} from "../utils/Zoom";
import {Link} from "react-router-dom";
import {useEffect, useState} from "react";
import {MDBDropdown, MDBDropdownItem, MDBDropdownLink, MDBDropdownMenu, MDBDropdownToggle} from "mdb-react-ui-kit";

export function Home() {
    return (
        <>
            <main>
                <h1>Zoom Buildertrend project</h1>
                <p>Welcome to the zoom Buildertrend project! We </p>
            </main>
        </>
    );
}