import {Link} from "react-router-dom";
import {useEffect, useState} from "react";

export function Calendar() {
    const [advice, setAdvice] = useState("");

    useEffect(() => {
        const url = "https://api.adviceslip.com/advice";

        const grabDataFromBackend = async() => {
            try {
                const response = await fetch(url);
                await response.json().then((data) => {
                    // I've assigned the data within .then in order to assure promise resolution
                    setAdvice(data.slip.advice);
                });
            } catch (error) {
                console.log("error", error);
            }
        }

        console.log(grabDataFromBackend());
    }, []);

    return (
        <>
            <main>
                <div>
                    <p>
                        This is some advice queried from a website! We will surface scheduled events below.
                    </p>
                    <p>
                        {advice}
                    </p>
                </div>
            </main>
            <nav>
                <Link to="/">Home</Link>
            </nav>
        </>
    );
}