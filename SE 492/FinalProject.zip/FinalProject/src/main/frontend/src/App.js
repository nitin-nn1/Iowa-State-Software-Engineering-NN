import {ZoomMtg} from "@zoomus/websdk";

import Webpages from "./pages";

import './resources/App.css'

ZoomMtg.setZoomJSLib('https://source.zoom.us/2.2.0/lib', '/av');

ZoomMtg.preLoadWasm();
ZoomMtg.prepareWebSDK();
// loads language files, also passes any error messages to the ui
ZoomMtg.i18n.load('en-US');
ZoomMtg.i18n.reload('en-US');

function App() {
  return (
    <>
      <Webpages/>
    </>
  );
};

export default App;

