import React, {useState} from "react";
import {getSignature} from "../utils/Zoom";

class MeetingForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            meetingId: '',
            name: '',
            meetingPassword: '',
            role: '',
            hostMeeting: false,
            zakToken: ''
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleSubmit(e) {
        e.preventDefault();
        getSignature(this.state);
    }

    handleChange(e) {
        this.setState({
            ...this.state,
            [e.target.name]: e.target.value,
        });
    };

    render() {
        return (
            <form onSubmit={this.handleSubmit}>
                <div>
                    <label>Name</label>
                    <input
                        type="text"
                        class="form-control"
                        id="name-field"
                        name="name"
                        onChange={this.handleChange}
                        placeholder="Enter Name"
                    />
                    <small id="nameHelp" className="form-text text-muted">
                        This will be what your name appears as in call!
                    </small>
                </div>
                <div>
                    <label>Meeting ID</label>
                    <input
                        type="number"
                        class="form-control"
                        id="meeting-id-field"
                        name="meetingId"
                        onChange={this.handleChange}
                        placeholder="Meeting Number"
                        readOnly={this.state.hostMeeting}
                        required={!this.state.hostMeeting}
                    />
                    <small id="meetingIdHelp" className="form-text text-muted">
                        Don't include dashes in meeting IDs.
                    </small>
                </div>
                <div>
                    <label>Meeting Password</label>
                    <input
                        type="text"
                        class="form-control"
                        id="meeting-password-field"
                        name="meetingPassword"
                        onChange={this.handleChange}
                    />
                    <small id="meetingIdHelp" className="form-text text-muted">
                        Leave blank if meeting doesn't have/need a password.
                    </small>
                </div>
                <div>
                    <label>Role</label>
                    <select
                        name="hostMeeting"
                        class="form-control"
                        id="meeting-role-field"
                        onChange={this.handleChange}
                    >
                        <option value={false}>Join</option>
                        <option value={true}>Host</option>
                    </select>
                    <small id="meetingIdHelp" className="form-text text-muted">
                        This determines whether you will be hosting or joining a meeting
                    </small>
                </div>
                <div>
                    <button type="submit" className="btn btn-primary" onSubmit={this.handleSubmit}>
                        Submit
                    </button>
                </div>
                <button className="btn btn-primary" onClick={
                    getSignature
                }>
                    Start meeting
                </button>
            </form>
        );
    }
};


export default MeetingForm;