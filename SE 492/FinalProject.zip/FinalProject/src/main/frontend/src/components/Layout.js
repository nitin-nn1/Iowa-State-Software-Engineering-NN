import React, {useState} from "react";
import {
  MDBContainer,
  MDBDropdown,
  MDBDropdownItem,
  MDBDropdownLink,
  MDBDropdownMenu,
  MDBDropdownToggle,
  MDBFooter,
  MDBIcon,
  MDBNavbar,
  MDBNavbarItem,
  MDBNavbarNav,
} from "mdb-react-ui-kit";
import {Link} from "react-router-dom";


const Layout = ({children}) => {
  return (
    <React.Fragment>
      <MDBNavbar expand='lg' dark style={{backgroundColor: '#0f587b'}}>
        <MDBContainer fluid style={{backgroundColor: '#0f587b'}}>
          <Link class="navbar-brand mt-lg-0" to="/">
            <img
              src="/assets/bt-icon2.jpg"
              height="40"
              alt="MDB Logo"
              loading="lazy"
            />
          </Link>


          <MDBNavbarNav className='mr-auto mb-2 mb-lg-0 text-white'>
            <MDBNavbarItem>
              <Link class="nav-link text-white" to="/">Home</Link>
            </MDBNavbarItem>
            <MDBNavbarItem>
              <Link class="nav-link text-white" to="/Calendar">Calendar</Link>
            </MDBNavbarItem>
            <MDBNavbarItem>
              <Link class="nav-link text-white" to="/Zoom">Zoom</Link>
            </MDBNavbarItem>
          </MDBNavbarNav>

          <MDBNavbarItem>
            <MDBDropdown>
              <MDBDropdownToggle tag='a' className='nav-link text-white'>
                <MDBIcon className='fa-user'/>
              </MDBDropdownToggle>
              <MDBDropdownMenu>
                <MDBDropdownItem>
                  <MDBDropdownLink>Action</MDBDropdownLink>
                </MDBDropdownItem>
                <MDBDropdownItem>
                  <MDBDropdownLink>Another action</MDBDropdownLink>
                </MDBDropdownItem>
                <MDBDropdownItem>
                  <MDBDropdownLink>Something else here</MDBDropdownLink>
                </MDBDropdownItem>
              </MDBDropdownMenu>
            </MDBDropdown>
          </MDBNavbarItem>

        </MDBContainer>
      </MDBNavbar>

      <main>{children}</main>

      <MDBFooter color='white' className='text-center text-lg-left fixed-bottom' style={{backgroundColor: '#0f587b'}}>
        <div className='text-center p-3' style={{backgroundColor: 'rgba(0, 0, 0, 0.2)'}}>
          &copy; {new Date().getFullYear()} Copyright:{' '}
          <a className='text-white text-decoration-underline' href='https://sdmay22-27.sd.ece.iastate.edu/'
             target='_blank' rel='noreferrer'>
            sdmay22-27 Iowa State University for Buildertrend
          </a>
        </div>
      </MDBFooter>
    </React.Fragment>
  );
};

export default Layout;