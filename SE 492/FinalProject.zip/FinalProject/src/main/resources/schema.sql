-- Author: Keven Lin
DROP TABLE IF EXISTS USER;
create table if not exists USER (
    id int not NULL AUTO_INCREMENT,
    email varchar(255),
    fname varchar(255),
    lname varchar(255),
    password varchar(255),
    username varchar(255)
    );

create table if not exists MEETING (
    id int not NULL AUTO_INCREMENT,
    duration int not NULL,

    agenda varchar(255),
    password varchar(255),
    audio varchar(255),

    default_password NUMBER(1),
    CONSTRAINT checkBool CHECK (default_password IN (1,0))
    );

create table if not exists PARTICIPANTS (
    id int not NULL AUTO_INCREMENT,
    meetingID int not NULL,
    userID int not NULL
    );