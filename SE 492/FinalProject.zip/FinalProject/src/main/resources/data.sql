-- author: Keven and Adam
--Temp Users
insert into USER (email, fname, lname, password, username) values ('abanwell@iastate.edu', 'Adam', 'Banwell', 'password', 'abanwell');
insert into USER (email, fname, lname, password, username) values ('keven@iastate.edu', 'Keven', 'Lin', 'tesla', 'keven');
insert into USER (email, fname, lname, password, username) values ('rohmishra@iastate.edu', 'The', 'Dark Knight', 'Offsetx40', 'Github69');

--insert into MEETING (duration, participantsID, agenda, password, audio) values (20, 1, 'Frontend', '1234', 'voip');
insert into USER (email, fname, lname, password, username) values ('home4nit@gmail.com', 'Nitin', 'DeezNuts', 'awesomarcherttv', 'intellij<3');
