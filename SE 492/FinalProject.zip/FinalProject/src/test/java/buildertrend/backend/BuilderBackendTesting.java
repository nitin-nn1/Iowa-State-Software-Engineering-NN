package buildertrend.backend;

import buildertrend.backend.*;
import buildertrend.backend.Entity.Meeting;
import buildertrend.backend.Entity.User;
import buildertrend.backend.Repository.MeetingDB;
import buildertrend.backend.Repository.UserDB;
import buildertrend.backend.Service.UserService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import javax.sound.midi.Soundbank;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;


@RunWith(SpringRunner.class)
public class BuilderBackendTesting {
    @TestConfiguration
    static class userConfig {
        @Bean
        public UserService service() {
            return new UserService();
        }

        @Bean
        UserDB getRepo() {
            return mock(UserDB.class);
        }

        @Bean
        MeetingDB getMeetingRepo() {
            return mock(MeetingDB.class);
        }
    }

    @Autowired
    private UserService s;

    @Autowired
    private UserDB repo;

    @Autowired
    private MeetingDB meetingDB;

    @Test
    public void testallRestAPI() throws InterruptedException {
        TimeUnit.SECONDS.sleep(12);
        List<User> l = new ArrayList<User>();

        when(repo.findAll()).thenReturn(l);

        when(repo.save((User) any(User.class))).thenAnswer(x ->
        {
            User r = x.getArgument(0);
            l.add(r);
            return null;
        });

        System.out.println(s.findByPassword("12345"));
    }
    @Test
    public void testAllBackend() throws InterruptedException{
        TimeUnit.SECONDS.sleep(15);
        List<User> l = new ArrayList<User>();

        when(repo.findAll()).thenReturn(l);

        when(repo.save((User) any(User.class))).thenAnswer(x ->
        {
            User r = x.getArgument(0);
            l.add(r);
            return null;
        });

        System.out.println(s.findByEmail("buildertrend@gmail.com"));
    }

    @Test
    public void testAllUseCases() throws InterruptedException{
        TimeUnit.SECONDS.sleep(10);
        List<User> l = new ArrayList<User>();

        when(repo.findAll()).thenReturn(l);

        when(repo.save((User) any(User.class))).thenAnswer(x ->
        {
            User r = x.getArgument(0);
            l.add(r);
            return null;
        });


        System.out.println(s.findByFname("Builder"));
    }
    @Test
    public void testPostRequests() throws InterruptedException{
        TimeUnit.SECONDS.sleep(8);
        List<Meeting> l = new ArrayList<Meeting>();

        when(meetingDB.findAll()).thenReturn(l);

        when(meetingDB.save((Meeting) any(Meeting.class))).thenAnswer(x ->
        {
            Meeting r = x.getArgument(0);
            l.add(r);
            return null;
        });

        System.out.println(meetingDB.findByID(0));
    }

    @Test
    public void testDatabasePings() throws InterruptedException{
        TimeUnit.SECONDS.sleep(3);
        List<User> l = new ArrayList<User>();

        when(repo.findAll()).thenReturn(l);

        when(repo.save((User) any(User.class))).thenAnswer(x ->
        {
            User r = x.getArgument(0);
            l.add(r);
            return null;
        });

        System.out.println(s.findByUserName("builder.trend"));
    }



}

