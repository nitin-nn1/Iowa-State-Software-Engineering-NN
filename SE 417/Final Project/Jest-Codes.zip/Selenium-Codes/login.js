

function valid(){
    var username = document.getElementById("txtUsername").value;
    var password = document.getElementById("txtPassword").value;
    var checker = true;
    var empty = true;
    // alert(username);
    if(username == ""){
        checker = false;
        empty = true;
    }
    else if(username == "coms417" && password == "Selenium"){
      checker=true;
      empty = false;
    } else{
      checker=false;
      empty = false;
    }
    if(checker){
      document.getElementById("formLogin").style.display="none";
      document.getElementById("txtMessageLogin").innerHTML="Login Success!";
      //display image
      var x = document.createElement("BUTTON");
      x.id = "button2";
      //x.className = "button";
        x.setAttribute("type", "button")
      x.onclick = function(){show_image()};
      // document.getElementById(x).style.background="rgba(255,0,0.6)";
      document.body.appendChild(x);
    }
    else if(empty){
        document.getElementById("txtMessageLogin").innerHTML="Login Failed: Please enter a username!";
    }
    else{
      document.getElementById("txtMessageLogin").innerHTML="Login Failed!";
    }
}

function show_image() {//src, width, height, alt
    var img = document.createElement("img");
    img.src = "rick-roll.gif";
    img.width = 500;
    img.height = 250;
    img.alt = 'rickroll';

    // This next line will just add it to the <body> tag
    document.body.appendChild(img);
}
