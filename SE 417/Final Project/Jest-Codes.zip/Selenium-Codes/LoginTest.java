package lab06;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginTest {

	static WebDriver driver;

//	Change your selenium driver path here
	static String pathChromeDriver="C:/Users/Nitin's PC/Downloads/chromedriver.exe";
	static String pathLoginPage="file:///F:/FILES/Iowa State University/SeniorYear/Spring'22/SE 417/Lab06-TestPlatforms-SampleCodes/Selenium-Codes/login.html";

	String txtUsername="txtUsername";
	String txtPassword="txtPassword";
	String btnLogin="btnLogin";
	String txtMessageLogin="txtMessageLogin";
	String button2 = "button2";

	@BeforeClass
	public static void openBrowser()
	{
		System.setProperty("webdriver.chrome.driver", pathChromeDriver);
		driver= new ChromeDriver() ;
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}

	@AfterClass
	public static void closeBrowser() {
		driver.quit();
	}

	@Test
	public void loginSuccessTest() throws InterruptedException {
		driver.get(pathLoginPage);
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@id='"+txtUsername+"']")).sendKeys("coms417");
		driver.findElement(By.xpath("//input[@id='"+txtPassword+"']")).sendKeys("Selenium");

		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id='"+btnLogin+"']")).click();

		String strMessage=driver.findElement(By.xpath("//label[@id='"+txtMessageLogin+"']")).getText();
		assertEquals("Failed test case", strMessage, "Login Success!");
	}

	@Test
	public void loginFailedTest() throws InterruptedException {
		driver.get(pathLoginPage);
		driver.manage().window().maximize();
		driver.findElement(By.id(txtUsername)).sendKeys("test");
		driver.findElement(By.id(txtPassword)).sendKeys("417Class");

		Thread.sleep(1000);
		driver.findElement(By.id(btnLogin)).click();
		String strMessage=driver.findElement(By.xpath("//label[@id='"+txtMessageLogin+"']")).getText();
		assertEquals("Failed test case", strMessage, "Login Failed!");
	}
	@Test
	public void loginButtonTest() throws InterruptedException {
		driver.get(pathLoginPage);
		driver.manage().window().maximize();
		//driver.findElement(By.xpath("//input[@id='"+txtUsername+"']")).sendKeys("coms417");
		//driver.findElement(By.xpath("//input[@id='"+txtPassword+"']")).sendKeys("Selenium");

		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id='"+btnLogin+"']")).click();

		String strMessage=driver.findElement(By.xpath("//label[@id='"+txtMessageLogin+"']")).getText();
		assertEquals("Button pressed!", strMessage, "Login Failed: Please enter a username!");
	}
	@Test
	public void GIFTestSuccess() throws InterruptedException {
		driver.get(pathLoginPage);
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@id='"+txtUsername+"']")).sendKeys("coms417");
		driver.findElement(By.xpath("//input[@id='"+txtPassword+"']")).sendKeys("Selenium");

		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id='"+btnLogin+"']")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("button2")).click();
		Thread.sleep(1000);

		boolean imgPass = true;
		try {
			WebElement imgElement = driver.findElement(By.xpath("//img[contains(@src,'rick-roll.gif')]"));
		}
		catch(Exception e){
			imgPass = false;
		}
		assertEquals("Image Shown!", imgPass, true);
	}

	@Test
	public void GIFTestFail() throws InterruptedException {
		driver.get(pathLoginPage);
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@id='"+txtUsername+"']")).sendKeys("coms417");
		driver.findElement(By.xpath("//input[@id='"+txtPassword+"']")).sendKeys("Selenium");

		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id='"+btnLogin+"']")).click();
		Thread.sleep(1000);
		//driver.findElement(By.id("button2")).click();
		Thread.sleep(1000);

		boolean imgPass = true;
		try {
			WebElement imgElement = driver.findElement(By.xpath("//img[contains(@src,'rick-roll.gif')]"));
		}
		catch(Exception e){
			imgPass = false;
		}
		assertEquals("Image Shown!", imgPass, false);
	}




}
