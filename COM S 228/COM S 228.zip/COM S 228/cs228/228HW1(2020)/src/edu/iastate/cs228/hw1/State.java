package edu.iastate.cs228.hw1;

/**
 *
 * Many different forms of life
 *
 */
public enum State {
    BADGER, EMPTY, FOX, GRASS, RABBIT
}
