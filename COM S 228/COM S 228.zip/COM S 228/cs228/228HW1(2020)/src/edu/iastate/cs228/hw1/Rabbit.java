package edu.iastate.cs228.hw1;

/**
 *  
 * @author
 * Nitin Nagavel
 */

/*
 * A rabbit eats grass and lives no more than three years.
 */
public class Rabbit extends Animal 
{	
	/**
	 * Creates a Rabbit object.
	 * @param p: plain  
	 * @param r: row position 
	 * @param c: column position
	 * @param a: age 
	 */
	public Rabbit (Plain p, int r, int c, int a) 
	{
		// TODO
		plain = p;
		row = r;
		column = c;
		age = a;
	}
		
	// Rabbit occupies the square.
	public State who()
	{
		// TODO  
		return State.RABBIT;
	}
	
	/**
	 * A rabbit dies of old age or hunger. It may also be eaten by a badger or a fox.  
	 * @param pNew     plain of the next cycle 
	 * @return Living  new life form occupying the same square
	 */
	public Living next(Plain pNew){
		// TODO 
		// 
		// See Living.java for an outline of the function. 
		// See the project description for the survival rules for a rabbit. 
		//return null;
		int arr[] = new int[NUM_LIFE_FORMS];
		this.census(arr);
		Animal rabbit = (Animal)plain.grid[row][column];
		if(rabbit.myAge() >= RABBIT_MAX_AGE) {
			return new Empty(pNew, this.row, this.column);
		}
		else if(arr[GRASS] == 0) {
			return new Empty(pNew, this.row, this.column);
		}
		else if((arr[FOX] + arr[BADGER] >= arr[RABBIT]) && (arr[BADGER] < arr[FOX])){
			return new Fox(pNew, this.row, this.column, 0);
		}
		else if(arr[BADGER] > arr[RABBIT]) {
			return new Badger(pNew, this.row, this.column, 0);
		}
		else {
			return new Rabbit(pNew, this.row,this.column, age+=1);
		}


	}
}
