package iastate.cs228.hw2;

/**
 * 
 * Four sorting algorithms 
 * @author Nitin Nagavel
 */
public enum Algorithm 
{
	SelectionSort, InsertionSort, MergeSort, QuickSort
}
